"""Examples of using prompt decorators with OpenAI."""
