"""Utility functions for the OpenAI prompt decorator demo."""
