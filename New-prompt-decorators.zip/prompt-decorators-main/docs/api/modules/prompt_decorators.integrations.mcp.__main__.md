# __main__

Command-line entry point for running the Prompt Decorators MCP server.

Usage:
    python -m prompt_decorators.integrations.mcp [`--host HOST`] [`--port PORT`] [`--verbose`]

## Functions

### `main`

Run the Prompt Decorators MCP server.

**Signature:** `main() -> None`
