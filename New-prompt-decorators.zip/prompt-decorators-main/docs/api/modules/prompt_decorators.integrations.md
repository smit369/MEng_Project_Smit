# integrations

Integration modules for Prompt Decorators.

This package contains modules for integrating Prompt Decorators with
various frameworks, protocols, and platforms.

## Public API

This module exports the following components:

- `mcp`: module - Model Context Protocol (MCP) integration for Prompt Decorators
