# claude_desktop

Entry point for running the Prompt Decorators MCP server for Claude Desktop.

Usage:
    python -m prompt_decorators.integrations.mcp.claude_desktop [`--host HOST`] [`--port PORT`] [`--verbose`]

## Functions

### `main`

Run the Prompt Decorators MCP server for Claude Desktop.

**Signature:** `main() -> None`
